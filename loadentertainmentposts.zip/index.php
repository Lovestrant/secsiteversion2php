
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecSitee</title>

    <!--bootstrap links-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>




<!-- google icons link-->
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <div class="page-header">
   
<p>
    <h1>Welcome to <br> SecSitee</h1>
</p>


</div>
<div class= "container">
    <h2>Post anonymously</h2>
    <h3>The SecSitee is the site where your anonymity is guaranteed.</h3>
    <a href="general.php"><button class=" btn btn-danger"  id="btn">SEE WHAT IS NEW</button></a>
    </div>

    <style>
        h1{
            color: red;
            text-align: centre;
            justify-content: centre;
        }

        h2,h3{
            margin-top: 6%;
        }
        .page-header{
        background-color: black;
    }
    body{
        text-align: center;
        justify-content: centre;
    }
   #btn{
      
        border-radius: 10px;
       width: 100%;
        margin-left: 0%; 
        margin-top: 50px;
    }
    </style>
  

</body>
</html>
